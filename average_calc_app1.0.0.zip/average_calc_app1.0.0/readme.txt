資訊
名字:平均數計算機
支援:windows10/11
作者:discord:ethanlau#2560
官方discord群組:https://discord.gg/WACCK3mbm2
發行日期:2022年12月10日
發行版本:1.0.0
價錢:免費